import cfnresponse
import json
import boto3
import time
import sys

responseStr = {'Status' : {}}


def updateNetworkConfig(HANAInstanceID,HANAIPAddress,AWSRegion):
    CommandArray = []
    CommandArray.append('nameSrv=`tail -2 /etc/resolv.conf | grep nameserver | grep -v grep | awk \'{print $2}\'`')
    CommandArray.append('searchList=`tail -2 /etc/resolv.conf | grep search | grep -v grep | awk \'{print $2}\'`')
    CommandArray.append('sed -i".bak" "/\\NETCONFIG_DNS_STATIC_SEARCHLIST\b/d" /etc/sysconfig/network/config')
    CommandArray.append('echo -e "NETCONFIG_DNS_STATIC_SEARCHLIST=\"$searchList\"">> /etc/sysconfig/network/config')
    CommandArray.append('sed -i".bak" "/\\NETCONFIG_DNS_STATIC_SERVERS\b/d" /etc/sysconfig/network/config')
    CommandArray.append('echo -e "NETCONFIG_DNS_STATIC_SERVERS=\"$nameSrv\"">> /etc/sysconfig/network/config')
    CommandArray.append('echo "BOOTPROTO=\'static\'" > /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "MTU=\'9000\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "REMOTE_IPADDR=\'\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "STARTMODE=\'auto\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "LINK_REQUIRED=\'no\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "LNIK_READY_WAIT=\'5\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "CLOUD_NETCONFIG_MANAGE=\'yes\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "BROADCAST=\'\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "ETHTOOL_OPTIONS=\'\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('echo "IPADDR=\''+HANAIPAddress+'/24\'" >> /etc/sysconfig/network/ifcfg-eth0')
    CommandArray.append('tempGW=`netstat -r -n | grep UG | grep -v grep | awk \'{print $2}\'`')
    CommandArray.append('echo "# Destination     Gateway           Netmask            Interface  Options" > /etc/sysconfig/network/ifroute-eth0')
    CommandArray.append('echo "default $tempGW       -       eth0" >> /etc/sysconfig/network/ifroute-eth0')
    CommandArray.append('service network restart')
    CommandArray.append('service amazon-ssm-agent stop')
    CommandArray.append('service amazon-ssm-agent start')    
    CommandArray.append('echo "done"')
    CommentStr = 'Network config'
    InstanceIDArray =[HANAInstanceID]
    return executeSSMCommands(CommandArray,InstanceIDArray,CommentStr,AWSRegion)


def executeSSMCommands(CommandArray,InstanceIDArray,CommentStr,AWSRegion):
    session = boto3.Session()
    ssmClient = session.client('ssm', region_name=AWSRegion)
    ssmCommand = ssmClient.send_command(
                InstanceIds=InstanceIDArray,
                DocumentName='AWS-RunShellScript',
                TimeoutSeconds=30,
                Comment=CommentStr,
                Parameters={
                        'commands': CommandArray
                    }
                )
    L_SSMCommandID = ssmCommand['Command']['CommandId']
    status = 'Pending'
    while status == 'Pending' or status == 'InProgress':
        status = (ssmClient.list_commands(CommandId=L_SSMCommandID))['Commands'][0]['Status']
        time.sleep(3)

    if (status == "Success"):
        #response = ssmClient.list_command_invocations(CommandId=L_SSMCommandID,InstanceId=InstanceIDArray[0],Details=True)
        return 1
    else:
        return 0

def manageRetValue(retValue,FuncName,input, context):
    global responseStr
    if (retValue == 1):
        responseStr['Status'][FuncName] = "Success"
    else:
        responseStr['Status'][FuncName] = "Failed"
        cfnresponse.send(input, context, cfnresponse.FAILED, responseStr)
        sys.exit(0)


def lambda_handler(input, context):
    global responseStr
    try:
        if (input['RequestType'] == "Update") or (input['RequestType'] == "Create"):
            HANAPrimaryInstanceID = input['ResourceProperties']['PrimaryInstanceId']
            HANASecondaryInstanceID = input['ResourceProperties']['SecondaryInstanceId']
            AWSRegion = input['ResourceProperties']['AWSRegion']
            HANAPrimaryIPAddress = input['ResourceProperties']['HANAPrimaryIPAddress']
            HANASecondaryIPAddress = input['ResourceProperties']['HANASecondaryIPAddress']

            retValue = updateNetworkConfig(HANAPrimaryInstanceID,HANAPrimaryIPAddress,AWSRegion)
            manageRetValue(retValue,"updateNetworkConfigPrimary",input, context)

            retValue = updateNetworkConfig(HANASecondaryInstanceID,HANASecondaryIPAddress,AWSRegion)
            manageRetValue(retValue,"updateNetworkConfigSecondary",input, context)

            cfnresponse.send(input, context, cfnresponse.SUCCESS, {'Status':json.dumps(responseStr)})
        else:
            responseStr['Status'] = 'Nothing to do as Request Type is : ' + input['RequestType']
            cfnresponse.send(input, context, cfnresponse.SUCCESS, {'Status':json.dumps(responseStr)})
    except Exception as e:
        responseStr['Status'] = str(e)
        cfnresponse.send(input, context, cfnresponse.FAILED, {'Status':json.dumps(responseStr)})